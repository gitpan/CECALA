#!/usr/bin/perl -w

use lib('.');
use Viewport;

$v = new Viewport();
$v->print();
